export enum StatusType {
  ACTIVE = "active",
  INACTIVE = "inactive",
  ARCHIVED = "archived", // optional if you're not using it yet
}
