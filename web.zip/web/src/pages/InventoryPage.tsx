// src/pages/InventoryPage.tsx
import React, { useEffect, useState } from "react";
import InventoryTable from "../components/Inventory/InventoryTable";

import type { Product } from "../types/ProductTypes";

const InventoryPage = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchProducts = async () => {
    try {
      const result = await getAllProducts();
      setProducts(result);
    } catch (error) {
      console.error("Failed to fetch products:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">Inventory Management</h1>
      {loading ? (
        <p className="text-gray-500">Loading...</p>
      ) : (
        <InventoryTable
          products={products}
          onStockIn={(p) => console.log("Stock in:", p)}
          onStockOut={(p) => console.log("Stock out:", p)}
          onAdjust={(p) => console.log("Adjust:", p)}
        />
      )}
    </div>
  );
};

export default InventoryPage;
